package Ej6;

public class Hiloej6 extends Thread {
    public Hiloej6(int prioridad) { this.setPriority(prioridad); }

    public void run() {
        int contador = 0;


}
}
